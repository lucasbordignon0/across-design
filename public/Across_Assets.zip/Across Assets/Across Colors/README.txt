Across brand assets — September 2026

Source: https://www.figma.com/design/hRaAhovZJOTFySyJhrlYiU/
Use approved artwork without distortion, rotation or effects. Keep clear space equal to the gap between symbol and wordmark.
White/aqua variants are for dark backgrounds; dark variants are for light backgrounds. SVG lettering is outlined. Logo PNGs are transparent 2x exports. Gradient PNGs are opaque artwork.
Fonts are not included. Supreme: https://www.fontshare.com/fonts/supreme
IvyPresto: https://fonts.adobe.com/fonts/ivypresto-headline

Dark is the default. Status colors are functional only. Aqua 500–950 are for gradients, illustration and tints, not UI text.
