Across brand assets — September 2026

Source: https://www.figma.com/design/hRaAhovZJOTFySyJhrlYiU/
Use approved artwork without distortion, rotation or effects. Keep clear space equal to the gap between symbol and wordmark.
White/aqua variants are for dark backgrounds; dark variants are for light backgrounds. SVG lettering is outlined. Logo PNGs are transparent 2x exports. Gradient PNGs are opaque artwork.
Fonts are not included. Supreme: https://www.fontshare.com/fonts/supreme
IvyPresto: https://fonts.adobe.com/fonts/ivypresto-headline

Across is the default palette. across-radial is the exact Figma-painted surface; the other radial artworks are applications of the documented palette stops. Palette strips and palettes.json document stop positions.
